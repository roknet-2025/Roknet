
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function About() {
  return (
    <div className="min-h-screen">
      <Header />
      
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h1 className="text-5xl font-bold text-gray-900 mb-6">Hakkımızda</h1>
              <div className="w-24 h-1 bg-red-500 mx-auto"></div>
            </div>

            <div className="prose prose-lg max-w-none">
              <div className="bg-gray-50 rounded-2xl p-8 mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-6">ROKNET Nedir?</h2>
                <p className="text-xl text-gray-700 leading-relaxed mb-6">
                  ROKNET, İMHAD Derneği ve NEFTAIHL iş birliğiyle yürütülen öğrenci merkezli bir roketçilik projesidir.
                </p>
                <p className="text-lg text-gray-600 leading-relaxed">
                  Amacımız; Gençlerin bilim ve teknoloji alanında aktif rol alayı başarmak, özgün tasarımlarla kendi 
                  roketimizi yarıştırmak ve Türkiye'nin farklı bölgelerinde düzenlenen yarışmalarda okulumuzu ve 
                  derneğimizi gururla temsil etmektir.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="bg-red-50 rounded-xl p-6">
                  <div className="w-16 h-16 flex items-center justify-center bg-red-100 rounded-full mb-4">
                    <i className="ri-building-line text-2xl text-red-600"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">İMHAD Derneği</h3>
                  <p className="text-gray-700">
                    Projemizin kurumsal ayağını oluşturan, gençlerin bilim ve teknoloji alanındaki 
                    gelişimini destekleyen dernek organizasyonumuz.
                  </p>
                </div>

                <div className="bg-red-50 rounded-xl p-6">
                  <div className="w-16 h-16 flex items-center justify-center bg-red-100 rounded-full mb-4">
                    <i className="ri-school-line text-2xl text-red-600"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">NEFTAIHL Okulu</h3>
                  <p className="text-gray-700">
                    Öğrencilerimizin eğitim aldığı, bilimsel düşünce ve yaratıcılığın desteklendiği 
                    akademik kurumumuz.
                  </p>
                </div>
              </div>

              <div 
                className="relative rounded-2xl overflow-hidden mb-12 h-96 bg-cover bg-center"
                style={{
                  backgroundImage: `url('https://readdy.ai/api/search-image?query=Group%20of%20young%20engineering%20students%20working%20together%20on%20rocket%20design%20project%20in%20modern%20laboratory%2C%20collaborative%20teamwork%20atmosphere%2C%20technical%20drawings%20and%20rocket%20models%20on%20tables%2C%20diverse%20team%20of%20teenagers%20focused%20on%20aerospace%20engineering%2C%20bright%20modern%20workspace%20with%20engineering%20tools%20and%20computers%2C%20inspiring%20educational%20environment&width=800&height=400&seq=about1&orientation=landscape')`
                }}
              >
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <div className="text-center text-white">
                    <h3 className="text-3xl font-bold mb-2">Birlikte Başarıyoruz</h3>
                    <p className="text-xl">İMHAD & NEFTAIHL İş birliği</p>
                  </div>
                </div>
              </div>

              <div className="bg-black text-white rounded-2xl p-8">
                <h3 className="text-3xl font-bold mb-6 text-center">Proje Hedeflerimiz</h3>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="w-16 h-16 flex items-center justify-center bg-red-600 rounded-full mx-auto mb-4">
                      <i className="ri-lightbulb-line text-2xl"></i>
                    </div>
                    <h4 className="text-xl font-semibold mb-2">Bilimsel Düşünce</h4>
                    <p className="text-gray-300">Gençlerin bilimsel düşünme becerisini geliştirmek</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 flex items-center justify-center bg-red-600 rounded-full mx-auto mb-4">
                      <i className="ri-tools-line text-2xl"></i>
                    </div>
                    <h4 className="text-xl font-semibold mb-2">Praktik Deneyim</h4>
                    <p className="text-gray-300">Model roket ve havacılık alanında deneyim kazandırmak</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 flex items-center justify-center bg-red-600 rounded-full mx-auto mb-4">
                      <i className="ri-flag-line text-2xl"></i>
                    </div>
                    <h4 className="text-xl font-semibold mb-2">Ulusal Katkı</h4>
                    <p className="text-gray-300">Türkiye'nin model roket teknolojilerine katkıda bulunmak</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
