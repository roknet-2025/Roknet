
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function Contact() {
  return (
    <div className="min-h-screen">
      <Header />
      
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h1 className="text-5xl font-bold text-gray-900 mb-6">İletişim</h1>
              <div className="w-24 h-1 bg-red-500 mx-auto mb-4"></div>
              <p className="text-xl text-gray-600">
                🛰️ Ziyaret Et - Takip Et - Destek Ol!
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12 mb-12">
              <div className="space-y-8">
                <div className="bg-gray-50 rounded-xl p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 flex items-center justify-center bg-red-100 rounded-full">
                      <i className="ri-map-pin-line text-xl text-red-600"></i>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">📍 Adres</h3>
                      <p className="text-gray-700">
                        Günaltay Mah. 4811. Sok. No:7<br />
                        35190 Karabağlar / İzmir
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-xl p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 flex items-center justify-center bg-red-100 rounded-full">
                      <i className="ri-phone-line text-xl text-red-600"></i>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">📞 Telefon (WhatsApp destekli)</h3>
                      <p className="text-gray-700">
                        <a href="tel:+905510789071" className="hover:text-red-600 transition-colors">
                          0551 078 90 71
                        </a>
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-xl p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 flex items-center justify-center bg-red-100 rounded-full">
                      <i className="ri-mail-line text-xl text-red-600"></i>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">📩 E-posta</h3>
                      <p className="text-gray-700">
                        <a href="mailto:modelroknet@gmail.com" className="hover:text-red-600 transition-colors">
                          modelroknet@gmail.com
                        </a>
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-xl p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 flex items-center justify-center bg-red-100 rounded-full">
                      <i className="ri-instagram-line text-xl text-red-600"></i>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">📸 Instagram</h3>
                      <p className="text-gray-700">
                        <a href="https://instagram.com/modelroknet" target="_blank" rel="noopener noreferrer" 
                           className="hover:text-red-600 transition-colors">
                          @modelroknet
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-900 text-white rounded-2xl p-8">
                <h3 className="text-2xl font-bold mb-6">Bize Ulaşın</h3>
                <form className="space-y-6" id="contact-form">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-2">Ad Soyad</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:outline-none focus:border-red-500"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-2">E-posta</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:outline-none focus:border-red-500"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium mb-2">Konu</label>
                    <input
                      type="text"
                      id="subject"
                      name="subject"
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:outline-none focus:border-red-500"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium mb-2">Mesaj</label>
                    <textarea
                      id="message"
                      name="message"
                      rows={4}
                      maxLength={500}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:outline-none focus:border-red-500"
                      required
                    ></textarea>
                    <p className="text-xs text-gray-400 mt-1">Maksimum 500 karakter</p>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors whitespace-nowrap"
                  >
                    Mesaj Gönder
                  </button>
                </form>
              </div>
            </div>

            <div className="bg-red-50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Sosyal Medyada Takip Edin</h3>
              <div className="flex justify-center space-x-6">
                <a href="https://instagram.com/modelroknet" target="_blank" rel="noopener noreferrer"
                   className="flex items-center space-x-3 bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                  <div className="w-12 h-12 flex items-center justify-center bg-pink-100 rounded-full">
                    <i className="ri-instagram-line text-2xl text-pink-600"></i>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Instagram</p>
                    <p className="text-sm text-gray-600">@modelroknet</p>
                  </div>
                </a>

                <a href="https://wa.me/905510789071" target="_blank" rel="noopener noreferrer"
                   className="flex items-center space-x-3 bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                  <div className="w-12 h-12 flex items-center justify-center bg-green-100 rounded-full">
                    <i className="ri-whatsapp-line text-2xl text-green-600"></i>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">WhatsApp</p>
                    <p className="text-sm text-gray-600">0551 078 90 71</p>
                  </div>
                </a>

                <a href="mailto:modelroknet@gmail.com"
                   className="flex items-center space-x-3 bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                  <div className="w-12 h-12 flex items-center justify-center bg-red-100 rounded-full">
                    <i className="ri-mail-line text-2xl text-red-600"></i>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">E-posta</p>
                    <p className="text-sm text-gray-600">modelroknet@gmail.com</p>
                  </div>
                </a>
              </div>
            </div>

            <div className="mt-12">
              <div className="bg-gray-100 rounded-2xl overflow-hidden">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3133.8947589445586!2d27.156842315529476!3d38.37719298653814!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14bbd94b7b7b7b7b%3A0x7b7b7b7b7b7b7b7b!2sG%C3%BCnaltay%20Mah.%204811.%20Sok.%20No%3A7%2C%2035190%20Karabağlar%2F%C4%B0zmir!5e0!3m2!1str!2str!4v1234567890123!5m2!1str!2str"
                  width="100%"
                  height="400"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
