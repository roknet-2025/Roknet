
import type { Metadata } from "next";
import { Geist, Geist_Mono, Pacifico } from "next/font/google";
import "./globals.css";

const pacifico = Pacifico({
  weight: '400',
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-pacifico',
})

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ROKNET - Genç Fikirlerden Model Rokete",
  description: "İMHAD Derneği ve NEFTAIHL iş birliğiyle yürütülen öğrenci merkezli model roketçilik projesi",
  icons: {
    icon: "https://static.readdy.ai/image/73c73ff687c061bb9b32c7710cd7c3e7/529d6c500223392990f9c08be12baaf9.png",
    shortcut: "https://static.readdy.ai/image/73c73ff687c061bb9b32c7710cd7c3e7/529d6c500223392990f9c08be12baaf9.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="tr" suppressHydrationWarning={true}>
      <head>
        <link rel="icon" href="https://static.readdy.ai/image/73c73ff687c061bb9b32c7710cd7c3e7/529d6c500223392990f9c08be12baaf9.png" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${pacifico.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}